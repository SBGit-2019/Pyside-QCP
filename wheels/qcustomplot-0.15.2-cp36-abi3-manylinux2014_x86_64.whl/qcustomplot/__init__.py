#from .QCustomPlot import QCP
#from .QCustomPlot import QCustomPlot
from .QCustomPlot import *

#__all__ = ['QCustomPlot']
#__all__ = list("Qt" + body for body in
#    "Core;Gui;Widgets;PrintSupport;Sql;Network;Test;Concurrent;X11Extras;Xml;XmlPatterns;Help;Multimedia;MultimediaWidgets;OpenGL;OpenGLFunctions;Positioning;Location;Qml;Quick;QuickControls2;QuickWidgets;RemoteObjects;Scxml;Script;ScriptTools;Sensors;SerialPort;TextToSpeech;Charts;Svg;DataVisualization;UiTools;WebChannel;WebEngineCore;WebEngine;WebEngineWidgets;WebSockets;3DCore;3DRender;3DInput;3DLogic;3DAnimation;3DExtras"
#    .split(";"))
__version__ = "0.15.2.1"
__version_info__ = (0, 15, 2.1, "", "")


